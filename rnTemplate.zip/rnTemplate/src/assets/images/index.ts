const celebrate = require('./celebrate.png');
const diamond = require('./diamond.png');

export {celebrate, diamond};
