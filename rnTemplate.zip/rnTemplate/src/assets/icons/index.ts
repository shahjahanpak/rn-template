const infoIcon = require('./info.png');
const questionIcon = require('./question.png');
const userPlaceholder = require('./userPlaceholder.png');

export {questionIcon, infoIcon, userPlaceholder};
