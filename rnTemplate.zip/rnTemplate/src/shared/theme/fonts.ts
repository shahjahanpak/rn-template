export const FONTS = {
  BOLD: 'NeueHaasDisplay-Bold',
  MEDIUM: 'NeueHaasDisplay-Mediu',
  ROMAN: 'NeueHaasDisplay-Roman',
  LIGHT: 'NeueHaasDisplay-Light',
  ITALIC: 'NeueHaasDisplay-BoldItalic',
  HARDY_REGULAR: 'Hardy-Regular',
};
