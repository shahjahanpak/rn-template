export const ROUTES = {
  WELCOME: 'welcome',
  LOGIN: 'login',
};
