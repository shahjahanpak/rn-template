export const ENDPOINTS = {
  LOGIN: 'loginUser',
};
